import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scaner = new Scanner(System.in);
        System.out.println("Пользователь вводит трехзначное число : ");
        int a = scaner.nextInt();
        System.out.println(a/100);
        System.out.println(a/10%10);
        System.out.println(a%10);
        System.out.println("Вторая часть ");
        Random random = new Random();
        int b = random.nextInt(999);
        long c = random.nextInt(999);
        double d = random.nextInt(999);
        System.out.println("Сгенерированио значение = " + b);
        System.out.println("Сгенерированио значение = " + c);
        System.out.println("Сгенерированио значение = " + d);
        System.out.println("Сумма трех чисел = " + (b + c + d));
        System.out.println("Произведение чисел = " + b * c *d );



    }
}